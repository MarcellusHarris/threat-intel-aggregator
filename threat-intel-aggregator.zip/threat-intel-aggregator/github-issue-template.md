### Threat Intel Aggregator TODOs

Tasks to finalise this repository for Agent Mode:

- [ ] **Export workflow JSON:** Add `flows/threat-intel-aggregator.json` to the repo so others can import the flow directly.
- [ ] **Diagram:** Include `assets/threat-intel-diagram.png` and embed it in the README.
- [ ] **Environment sample:** Provide a `.env.sample` for required variables (`THREAT_FEED_URL`, `THREAT_API_KEY`, `SLACK_WEBHOOK_URL`).
- [ ] **Scoring explanation:** Document how severity and confidence values are combined into a score and where to adjust the threshold.
- [ ] **Demo artefacts:** Add a GIF showing the hourly run and a sample Slack message; include example feed JSON in `/examples/` for testing.
