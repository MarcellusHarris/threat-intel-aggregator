# Agent Playbook for Threat Intel Aggregator

1. **Validate workflow:** Ensure that `flows/threat-intel-aggregator.json` imports correctly and the Cron schedule matches operational needs.
2. **Check scoring logic:** Review the function in the `Score Items` node to confirm that severity and confidence are combined correctly; adjust the threshold in the If node if required.
3. **Docs & examples:** Verify that the README describes environment variables (`THREAT_FEED_URL`, `THREAT_API_KEY`, `SLACK_WEBHOOK_URL`), and regenerate `assets/threat-intel-diagram.png` if the workflow changes.
4. **Examples:** Optionally run the workflow with a mock feed and update `/examples/` with sample input and Slack output.
5. **Issues:** Create or update issues covering missing demo GIFs, example feeds, or tests.
