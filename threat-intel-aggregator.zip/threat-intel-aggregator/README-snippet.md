## Threat Intel Aggregator

This n8n workflow runs on a schedule, fetches threat intelligence from a configurable feed, computes a simple risk score for each item, and posts alerts to Slack for anything that meets or exceeds a chosen threshold.

### Quick Start

1. **Import the workflow:** upload `flows/threat-intel-aggregator.json` in n8n.  
2. **Set environment variables:**
   - `THREAT_FEED_URL` – the base URL of your threat intelligence API (must return JSON with an `items` or `data` array).  
   - `THREAT_API_KEY` – API token used in the Authorization header when fetching the feed.  
   - `SLACK_WEBHOOK_URL` – Slack incoming webhook for notifications.

Once set up, the `Cron` node triggers the workflow hourly by default. The feed is fetched and each threat entry is scored by adding its `severity` and `confidence` values. Entries with a score of 8 or higher are sent to Slack. Adjust the threshold in the *If High Score?* node to tune sensitivity.

![Threat Intel Diagram](assets/threat-intel-diagram.png)
